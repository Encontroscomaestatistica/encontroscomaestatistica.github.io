# Parte 1: Tratamento dos dados
###############################################################################

feetAndInchesToM_conv <- function(feetAndInches) {
  num_conv <- as.numeric(feetAndInches[, 1]) * 30.48 +
    as.numeric(feetAndInches[, 2]) * 2.54
  
  return(num_conv / 100)
}

library(tidyverse)
library(ggrepel)
library(ggsoccer)
library(ggimage)

data <- read.csv('fifa19.csv', encoding = 'UTF-8')

data <- data %>% 
  filter(Weight != "", Height != "") %>% 
  mutate(Value = str_remove(Value, "^\200"), Wage = str_remove(Wage, "^\200")) %>% 
  mutate(Value = gsub("[K]$", "E3", Value)) %>% 
  mutate(Value = as.numeric(gsub("[M]$", "E6", Value))) %>% 
  mutate(Wage = as.numeric(gsub("[K]$", "E3", Wage))) %>% 
  mutate(Height = feetAndInchesToM_conv(
    as.data.frame(str_extract_all(Height, "\\d+", simplify = TRUE))
  )) %>% 
  mutate(Weight = as.numeric(gsub("lbs$", "", Weight)) / 2.2)

photo_ids <- str_extract_all(data$Photo, "\\d+", simplify = TRUE)[, 3]
photo_ids <- ifelse(nchar(photo_ids) != 6, paste0(strrep("0", 6 - nchar(photo_ids)), photo_ids), photo_ids)
photo_ids <- str_extract_all(photo_ids, "(.{3})", simplify = TRUE)

data <- data %>% 
  mutate(Photo = paste0("https://cdn.sofifa.com/players/", photo_ids[, 1], "/", photo_ids[, 2], "/19_60.png"))

# Parte 2: Análise dos dados
###############################################################################

# Objetivo: Encontrar jogadores bons e baratos

View(data)

data %>% 
  ggplot(aes(x = Overall, y = Value)) +
  geom_point(aes(color = Age)) +
  theme_minimal() +
  labs(x = "Proficiência Geral", y = "Valor de mercado", color = "Idade") +
  theme(legend.position = "bottom") +
  ggtitle("Análise do valor de mercado dos jogadores pela sua proficiência geral")

data %>% 
  ggplot(aes(x = Overall, y = log(Value))) +
  geom_point(aes(color = Age)) +
  theme_minimal() +
  labs(x = "Proficiência Geral", y = "Log do valor de mercado", color = "Idade") +
  theme(legend.position = "bottom") +
  ggtitle("Análise do log do valor de mercado dos jogadores pela sua proficiência geral")


log_value_data <- data %>% 
  mutate(log_value = log(Value)) %>% 
  filter(!is.infinite(log_value))

fit <- log_value_data %>% 
  glm(log_value ~ Overall + Age + Potential + Weak.Foot + Skill.Moves + Work.Rate + Position, data = ., family = gaussian)

summary(fit)

log_value_fit_data <- log_value_data %>% 
  mutate(predict_fit = predict(fit)) %>% 
  mutate(residual = log_value - predict_fit)

log_value_fit_data %>% 
  ggplot(aes(x = Overall, y = log(Value))) +
  geom_point(aes(color = Age)) +
  geom_label_repel(
    data = . %>% 
      filter(log_value > mean(log_value),
             residual < quantile(log_value_fit_data %>% 
                                   filter(log_value > mean(log_value)) %>% 
                                   pull(residual), 0.001)),
    aes(x = Overall, y = log_value, label = Name)
  )
  theme_minimal() +
  labs(x = "Proficiência Geral", y = "Log do valor de mercado", color = "Idade") +
  theme(legend.position = "bottom") +
  ggtitle("Análise do log do valor de mercado dos jogadores pela sua proficiência geral")

log_value_fit_data %>% 
  filter(log_value > mean(log_value),
         residual < quantile(log_value_fit_data %>% 
                               filter(log_value > mean(log_value)) %>% 
                               pull(residual), 0.001)) %>% 
  arrange(desc(Overall)) %>% 
  View()

unique_pos_name <- log_value_fit_data$Position %>% 
  unique()

outlier_players <- log_value_fit_data %>% 
  group_by(Position) %>% 
  filter(log_value > mean(log_value),
         residual < quantile(log_value_fit_data %>%
                               filter(log_value > mean(log_value)) %>%
                               pull(residual), 0.5)) %>%
  arrange(residual) %>% 
  group_split(.keep = FALSE) %>% 
  lapply(function(pos_data) {
    pos_data %>% 
      slice(1:10)
  })
names(outlier_players) <- sort(unique_pos_name)

fit_outlier_pos <- lapply(outlier_players, function(outlier_data) {
  plot_fit <- log_value_fit_data %>% 
    ggplot(aes(x = Overall, y = log_value)) +
    geom_point(aes(color = Age)) +
    geom_label_repel( 
      data = outlier_data,
      aes(x = Overall, y = log_value, label = Name)) +
    theme_minimal() +
    labs(x = "Proficiência Geral", y = "Log do valor de mercado",
         color = "Idade") +
    theme(legend.position = "bottom") +
    ggtitle("Análise do log do valor de mercado dos jogadores pela sua proficiência geral e valor ajustado")
  
  outlier_fit <- outlier_data %>% 
    arrange(desc(Overall))
  
  result <- list(plot = plot_fit, outlier = outlier_fit)
  
  return(result)
})
names(fit_outlier_pos) <- sort(unique_pos_name)

# Parte 3: Escolha do time
###############################################################################

# Formação 4-4-2 (GK, LB, RB, LCB, RCB, LM, LDM, RDM, RM, LS, RS)

fit_outlier_pos$GK$plot
fit_outlier_pos$GK$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$LB$plot
fit_outlier_pos$LB$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$RB$plot
fit_outlier_pos$RB$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$LCB$plot
fit_outlier_pos$LCB$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$RCB$plot
fit_outlier_pos$RCB$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$LM$plot
fit_outlier_pos$LM$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$LDM$plot
fit_outlier_pos$LDM$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$RDM$plot
fit_outlier_pos$RDM$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$RM$plot
fit_outlier_pos$RM$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$LS$plot
fit_outlier_pos$LS$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$RS$plot
fit_outlier_pos$RS$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

selected_team <- Reduce(rbind, lapply(fit_outlier_pos, function(pos) {
  pos$outlier[1, ]
})) %>% 
  mutate(Position = names(fit_outlier_pos)) %>% 
  select(Position, everything())
  
formation_442_data <- selected_team %>% 
  mutate(Name = ifelse(Name == "Gonçalo Guedes", "G. Guedes", Name)) %>% 
  slice(6, 8, 18, 9, 19, 13, 11, 21, 23, 14, 24) %>% 
  mutate(
    x = c(10, 30, 30, 25, 25, 65, 55, 55, 65, 85, 85),
    y = c(50, 90, 10, 65, 35, 85, 65, 35, 15, 61, 39)
  )

get_top_qual <- formation_442_data %>%
  select(ID, Crossing:GKReflexes) %>% 
  mutate(Defending = round(rowMeans(select(., Interceptions, Marking, Positioning, StandingTackle, SlidingTackle)), 0),
         Pace = round(rowMeans(select(., Acceleration:SprintSpeed)), 0),
         Passing = round(rowMeans(select(., ShortPassing, LongPassing)), 0),
         Physical = round(rowMeans(select(., Balance, Jumping, Stamina, Strength, Aggression)), 0),
         Shooting = round(rowMeans(select(., LongShots, Finishing)), 0)) %>% 
  select(ID, Curve, Defending, Dribbling, FKAccuracy, Pace, Passing, Penalties, Physical, Positioning, Shooting, ShotPower) %>% 
  rename(ID = 1, CRV = 2, DEF = 3, DRI = 4, FKA = 5, PAC = 6, PAS = 7, PEN = 8, PHY = 9, POS = 10, SHO = 11, PWR = 12)
nMat <- `dim<-`(names(get_top_qual)[-1][t(apply(get_top_qual[-1], 1, order, decreasing=TRUE))], dim(get_top_qual[-1]))
vMat <- t(apply(get_top_qual[-1], 1,  sort, decreasing=TRUE))
get_top_qual <- cbind(get_top_qual[1], data.frame(Map(cbind, as.data.frame(nMat, stringsAsFactors=FALSE), as.data.frame(vMat))))

# Parte 4: Gráfico da Escalação
###############################################################################

base_plot <- formation_442_data %>% 
  ggplot(aes(x = x, y = y)) +
    annotate_pitch(colour = "white", fill = "springgreen4", limits = FALSE) +
    theme_pitch() +
  
    geom_text(aes(x = 90, y = 102, label = paste0("Valor do time: \200", sum(Value) / 10^6, "M")),
              colour = "white", family = "mono", size = 6, fontface = "bold") +
  
    geom_image(aes(image = "bg_card.png"), size = 0.13) +
    geom_image(aes(x = x + 1.5, y = y + 4.5, image = Photo), size = 0.08) +
  
    geom_text(aes(y = y - 1, label = Name), colour = "white", family = "mono", size = 4, fontface = "bold") +
    geom_text(aes(x = x - 3.4, y = y + 6, label = Overall), colour = "orange", family = "mono", size = 5, fontface = "bold") +
    geom_text(aes(x = x - 3.4, y = y + 3.4, label = Position), colour = "white", family = "mono", size = 4, fontface = "bold") +
  
    geom_text(aes(x = x - 4.5, y = y - 4, label = get_top_qual$V1.2), colour = "white", family = "mono", size = 4, fontface = "bold") +
    geom_text(aes(x = x - 1.5, y = y - 4, label = get_top_qual$V1.1), colour = "white", family = "mono", size = 4, fontface = "bold") +
    
    geom_text(aes(x = x - 4.5, y = y - 6, label = get_top_qual$V2.2), colour = "white", family = "mono", size = 4, fontface = "bold") +
    geom_text(aes(x = x - 1.5, y = y - 6, label = get_top_qual$V2.1), colour = "white", family = "mono", size = 4, fontface = "bold") +
    
    geom_text(aes(x = x + 4.5, y = y - 4, label = get_top_qual$V3.1), colour = "white", family = "mono", size = 4, fontface = "bold") +
    geom_text(aes(x = x + 1.5, y = y - 4, label = get_top_qual$V3.2), colour = "white", family = "mono", size = 4, fontface = "bold") +
    
    geom_text(aes(x = x + 4.5, y = y - 6, label = get_top_qual$V4.1), colour = "white", family = "mono", size = 4, fontface = "bold") +
    geom_text(aes(x = x + 1.5, y = y - 6, label = get_top_qual$V4.2), colour = "white", family = "mono", size = 4, fontface = "bold") +
  
    ggtitle("FIFA 19: Escalação Sugerida por Análise Estatística",
            "Formação 4-4-2 com base no critério: bons e baratos")

base_plot + 
  theme(
    panel.background = element_rect(fill = "springgreen4"),
    plot.title = element_text(size = 20, face = "bold", family = "mono",
                              color = "tomato", hjust = 0.5, lineheight = 1.2),
    plot.subtitle = element_text(size = 15, family = "mono", face = "bold",
                                 hjust = 0.5)
  )

