data <- read.csv("games.csv")

library(tidyverse)

hist_turns <- ggplot(data, aes(x = turns, fill = cut(turns, 100))) +
  geom_histogram(binwidth = 20, show.legend = FALSE) +
  theme_minimal() +
  labs(x = "Número de rodadas", y = "Frequência") +
  ggtitle("Histograma do número de rodadas em jogos de xadrez")

hist_turns +
  scale_fill_discrete(h = c(150, 300), c = 70, l = 50)

subset_plot <- filter(data, winner == "white")
subset_plot <- select(subset_plot, opening_eco, white_rating)
subset_plot <- group_by(subset_plot, opening_eco)
subset_plot <- summarise(subset_plot, median = median(white_rating), n = n())
subset_plot <- filter(subset_plot, n >= 10)
subset_plot <- arrange(subset_plot, median)
subset_plot <- slice(subset_plot, 1:5, 143:147)


subset_plot <- filter(data, opening_eco %in% subset_plot$opening_eco)

fill <- "#4271AE"
lines <- "#1F3552"

ggplot(subset_plot,
       aes(x = reorder(opening_eco, white_rating, median), y = white_rating)) +
  geom_boxplot(fill = fill, colour = lines, alpha = 0.7, size = 1,
               outlier.colour = NA, coef = 1000) +
  geom_jitter(width = 0.05, alpha = 0.2, color = "orange") +
  theme_minimal() +
  labs(x = "Tipo de abertura", y = "Rating") +
  ggtitle("Boxplot do rating pelo tipo de abertura")

###############################################################################

subset_plot <- data %>%
  filter(winner == "white") %>% 
  select(opening_eco, white_rating) %>% 
  group_by(opening_eco) %>% 
  summarise(median = median(white_rating), n = n()) %>% 
  filter(n >= 10) %>% 
  arrange(median) %>% 
  slice(1:5, 143:147)

fill <- "#4271AE"
lines <- "#1F3552"

data %>% 
  filter(opening_eco %in% subset_plot$opening_eco) %>% 
  ggplot(aes(x = reorder(opening_eco, white_rating, median), y = white_rating)) +
    geom_boxplot(fill = fill, colour = lines, alpha = 0.7, size = 1,
                 outlier.colour = NA, coef = 1000) +
    geom_jitter(width = 0.05, alpha = 0.2, color = "orange") +
    theme_minimal() +
    labs(x = "Tipo de abertura", y = "Rating") +
    ggtitle("Boxplot do rating pelo tipo de abertura")

###############################################################################

subset_plot <- data %>%
  filter(winner != "draw") %>% 
  mutate(
    white_rating = ifelse(winner != "white", NA, white_rating),
    black_rating = ifelse(winner != "black", NA, black_rating)
  ) %>% 
  select(id, opening_eco, winner, white_rating, black_rating) %>% 
  pivot_longer(white_rating:black_rating, names_to = "type", values_to = "rating") %>% 
  filter(!is.na(rating)) %>% 
  select(-type)

cat_plot <- subset_plot %>% 
  group_by(opening_eco) %>% 
  summarise(median = median(rating), n = n()) %>% 
  filter(n >= 50) %>% 
  arrange(median) %>% 
  slice(c(1:10, 69:78))

subset_plot %>% 
  filter(opening_eco %in% cat_plot$opening_eco) %>% 
  ggplot(aes(x = reorder(opening_eco, rating, median), y = rating)) +
  geom_boxplot(fill = fill, colour = lines, alpha = 0.7, size = 1, outlier.colour = NA, coef = 1000) +
  geom_jitter(width = 0.05, alpha = 0.2, color = "orange") +
  theme_minimal() +
  labs(x = "Tipo de abertura", y = "Rating") +
  ggtitle("Boxplot do rating pelo tipo de abertura")






