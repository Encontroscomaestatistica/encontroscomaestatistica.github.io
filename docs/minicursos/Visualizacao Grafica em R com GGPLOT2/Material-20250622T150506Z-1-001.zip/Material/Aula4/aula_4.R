# Parte 1: Tratamento dos dados
###############################################################################

feetAndInchesToM_conv <- function(feetAndInches) {
  num_conv <- as.numeric(feetAndInches[, 1]) * 30.48 +
    as.numeric(feetAndInches[, 2]) * 2.54
  
  return(num_conv / 100)
}

library(tidyverse)
library(ggrepel)

data <- read.csv('fifa19.csv', encoding = 'UTF-8')

data <- data %>% 
  filter(Weight != "", Height != "") %>% 
  mutate(Value = str_remove(Value, "^\200"), Wage = str_remove(Wage, "^\200")) %>% 
  mutate(Value = gsub("[K]$", "E3", Value)) %>% 
  mutate(Value = as.numeric(gsub("[M]$", "E6", Value))) %>% 
  mutate(Wage = as.numeric(gsub("[K]$", "E3", Wage))) %>% 
  mutate(Height = feetAndInchesToM_conv(
    as.data.frame(str_extract_all(Height, "\\d+", simplify = TRUE))
  )) %>% 
  mutate(Weight = as.numeric(gsub("lbs$", "", Weight)) / 2.2)

# Parte 2: Análise dos dados
###############################################################################

# Objetivo: Encontrar jogadores bons e baratos

View(data)

data %>% 
  ggplot(aes(x = Overall, y = Value)) +
  geom_point(aes(color = Age)) +
  theme_minimal() +
  labs(x = "Proficiência Geral", y = "Valor de mercado", color = "Idade") +
  theme(legend.position = "bottom") +
  ggtitle("Análise do valor de mercado dos jogadores pela sua proficiência geral")

data %>% 
  ggplot(aes(x = Overall, y = log(Value))) +
  geom_point(aes(color = Age)) +
  theme_minimal() +
  labs(x = "Proficiência Geral", y = "Log do valor de mercado", color = "Idade") +
  theme(legend.position = "bottom") +
  ggtitle("Análise do log do valor de mercado dos jogadores pela sua proficiência geral")


log_value_data <- data %>% 
  mutate(log_value = log(Value)) %>% 
  filter(!is.infinite(log_value))

fit <- log_value_data %>% 
  glm(log_value ~ Overall + Age + Potential + Weak.Foot + Skill.Moves + Work.Rate + Position, data = ., family = gaussian)

summary(fit)

log_value_fit_data <- log_value_data %>% 
  mutate(predict_fit = predict(fit)) %>% 
  mutate(residual = log_value - predict_fit)

log_value_fit_data %>% 
  ggplot(aes(x = Overall, y = log(Value))) +
  geom_point(aes(color = Age)) +
  geom_label_repel(
    data = . %>% 
      filter(log_value > mean(log_value),
             residual < quantile(log_value_fit_data %>% 
                                   filter(log_value > mean(log_value)) %>% 
                                   pull(residual), 0.001)),
    aes(x = Overall, y = log_value, label = Name)
  )
  theme_minimal() +
  labs(x = "Proficiência Geral", y = "Log do valor de mercado", color = "Idade") +
  theme(legend.position = "bottom") +
  ggtitle("Análise do log do valor de mercado dos jogadores pela sua proficiência geral")

log_value_fit_data %>% 
  filter(log_value > mean(log_value),
         residual < quantile(log_value_fit_data %>% 
                               filter(log_value > mean(log_value)) %>% 
                               pull(residual), 0.001)) %>% 
  arrange(desc(Overall)) %>% 
  View()

unique_pos_name <- log_value_fit_data$Position %>% 
  unique()

outlier_players <- log_value_fit_data %>% 
  group_by(Position) %>% 
  filter(log_value > mean(log_value),
         residual < quantile(log_value_fit_data %>%
                               filter(log_value > mean(log_value)) %>%
                               pull(residual), 0.5)) %>%
  arrange(residual) %>% 
  group_split(.keep = FALSE) %>% 
  lapply(function(pos_data) {
    pos_data %>% 
      slice(1:10)
  })
names(outlier_players) <- sort(unique_pos_name)

fit_outlier_pos <- lapply(outlier_players, function(outlier_data) {
  plot_fit <- log_value_fit_data %>% 
    ggplot(aes(x = Overall, y = log_value)) +
    geom_point(aes(color = Age)) +
    geom_label_repel( 
      data = outlier_data,
      aes(x = Overall, y = log_value, label = Name)) +
    theme_minimal() +
    labs(x = "Proficiência Geral", y = "Log do valor de mercado",
         color = "Idade") +
    theme(legend.position = "bottom") +
    ggtitle("Análise do log do valor de mercado dos jogadores pela sua proficiência geral e valor ajustado")
  
  outlier_fit <- outlier_data %>% 
    arrange(desc(Overall))
  
  result <- list(plot = plot_fit, outlier = outlier_fit)
  
  return(result)
})
names(fit_outlier_pos) <- sort(unique_pos_name)

# Formação 4-4-2 (GK, LB, RB, LCB, RCB, LM, LDM, RDM, RM, LS, RS)

fit_outlier_pos$GK$plot
fit_outlier_pos$GK$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$LB$plot
fit_outlier_pos$LB$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$RB$plot
fit_outlier_pos$RB$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$LCB$plot
fit_outlier_pos$LCB$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$RCB$plot
fit_outlier_pos$RCB$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$LM$plot
fit_outlier_pos$LM$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$LDM$plot
fit_outlier_pos$LDM$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$RDM$plot
fit_outlier_pos$RDM$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$RM$plot
fit_outlier_pos$RM$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$LS$plot
fit_outlier_pos$LS$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)

fit_outlier_pos$RS$plot
fit_outlier_pos$RS$outlier %>% 
  select(Name, Nationality, Overall, Value, Club)


