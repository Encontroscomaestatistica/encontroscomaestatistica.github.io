feetAndInchesToM_conv <- function(feetAndInches) {
  num_conv <- as.numeric(feetAndInches[, 1]) * 30.48 +
    as.numeric(feetAndInches[, 2]) * 2.54
  
  return(num_conv / 100)
}

data <- read.csv('fifa19.csv', encoding = 'UTF-8')

library(tidyverse)

data %>% 
  select(Age, Overall, Value, Weight, Height) %>% 
  apply(2, unique)

data <- data %>% 
  filter(Weight != "", Height != "") %>% 
  mutate(Value = str_remove(Value, "^\200"), Wage = str_remove(Wage, "^\200")) %>% 
  mutate(Value = gsub("[K]$", "E3", Value)) %>% 
  mutate(Value = as.numeric(gsub("[M]$", "E6", Value))) %>% 
  mutate(Wage = as.numeric(gsub("[K]$", "E3", Wage))) %>% 
  mutate(Height = feetAndInchesToM_conv(
    as.data.frame(str_extract_all(Height, "\\d+", simplify = TRUE))
  )) %>% 
  mutate(Weight = as.numeric(gsub("lbs$", "", Weight)) / 2.2)

data %>% 
  ggplot(aes(Age)) +
  geom_density()

data %>% 
  ggplot(aes(Value)) +
  geom_histogram()

data %>% 
  ggplot(aes(Height)) +
  geom_histogram()

data %>% 
  ggplot(aes(Weight)) +
  geom_histogram()

data %>% 
  select(International.Reputation, Overall) %>% 
  group_by(International.Reputation) %>% 
  summarise(mean = mean(Overall)) %>% 
  ggplot(aes(y = International.Reputation, x = mean)) +
  geom_col(orientation = "y")
